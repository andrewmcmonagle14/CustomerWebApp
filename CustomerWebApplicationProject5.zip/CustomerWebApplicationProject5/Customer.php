<?php
require 'Person.php';
// Customer class derived from Person class
class Customer extends Person {
    private $customerNumber;
    private $mailingList;
    private $comments;

    public function __construct($lastName, $firstName, $address, $phone, $customerNumber, $mailingList, $comments) {
        parent::__construct($lastName, $firstName, $address, $phone);
        $this->customerNumber = $customerNumber;
        $this->mailingList = $mailingList;
        $this->comments = $comments;
    }

    // Getters and Setters
    public function getCustomerNumber() {
        return $this->customerNumber;
    }

    public function setCustomerNumber($customerNumber) {
        $this->customerNumber = $customerNumber;
    }

    public function getMailingList() {
        return $this->mailingList;
    }

    public function setMailingList($mailingList) {
        $this->mailingList = $mailingList;
    }

    public function getComments() {
        return $this->comments;
    }

    public function setComments($comments) {
        $this->comments = $comments;
    }
}

