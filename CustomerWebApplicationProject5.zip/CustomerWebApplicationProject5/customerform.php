<?php

$sSessId = 'ciktos8icvk11grtpkj3u610o3';
session_id($sSessId);
session_start();


require 'Customer.php'; 


// Get data from the form

$firstName=$_GET['fname'];
$lastName=$_GET['lname'];
$address=$_GET['address'];
$phone=$_GET['phone'];
$customerNumber=$_GET['customerNumber'];
$mailingList=$_GET['mailingList'];
$comments=$_GET['comments'];



//Create object 
$myCustomer=new Customer($firstName, $lastName, $address, $phone, $customerNumber, $mailingList, $comments);


addObjectToSession($myCustomer);



function addObjectToSession($obj)
{
    $address=$obj->getAddress();
    
    $_SESSION[$address]= serialize($obj);

        countCustomer();
 }


function  countCustomer()
{


$key=0;
foreach($_SESSION AS $value)
{
$key++;
}

echo("Number of Customer: ".$key);

	if($key==3)
	{

   		 header("Location: CustomerResult.php");
    		die();
	}
	else
	{
   		$key++;
		
    		include('customerapp.php');

	}
}



?>