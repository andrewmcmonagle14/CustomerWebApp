<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="utf-8">
 
   <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300,400;500;700&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="variables-palette-2.css" >
   <link rel="stylesheet" href="employee.css" >
</head>
<body>
 

   <section class="login">
      <h1>Add New Customer</h1>
      <form action="customerform.php" method="get">
         <label for="fname" >First Name</label>
         <input type="text" name="fname" class="error" required />
         
          <label for="lname" >Last Name</label>
         <input type="text" name="lname" class="error" required />

          <label for="address" >Address</label>
         <input type="text" name="address" class="error" required />

          <label for="phone" >Phone</label>
         <input type="number" name="phone" class="error" required />

         <label for="customerNumber" >Customer Number</label>
         <input type="number" name="customerNumber" class="error" required />

         <label for="mailingList" >Mailing List</label>
         <input type="text" name="mailingList" class="error" required />

         <label for="comments" >Comments</label>
         <input type="text" name="comments" class="error" required />
         
          <br />
         
          <button>
           Submit
         </button>
      </form>
   </section>   
  
</body>
</html>