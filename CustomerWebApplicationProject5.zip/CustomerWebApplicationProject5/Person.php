<?php

class Person {
    private $lastName;
    private $firstName;
    private $address;
    private $phone;

    public function __construct($lastName, $firstName, $address, $phone) {
        $this->lastName = $lastName;
        $this->firstName = $firstName;
        $this->address = $address;
        $this->phone = $phone;
    }

    // Getters and Setters
    public function getLastName() {
        return $this->lastName;
    }

    public function setLastName($lastName) {
        $this->lastName = $lastName;
    }

    public function getFirstName() {
        return $this->firstName;
    }

    
    public function setFirstName($firstName) {
        $this->firstName = $firstName;
    }

    public function getAddress() {
        return $this->address;
    }

    public function setAddress($address) {
        $this->address = $address;
    }

    public function getPhone() {
        return $this->phone;
    }

    public function setPhone($phone) {
        $this->phone = $phone;
    }
}









