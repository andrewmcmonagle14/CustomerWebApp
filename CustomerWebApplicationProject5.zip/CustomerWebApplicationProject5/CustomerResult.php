<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
 <link rel="stylesheet" href="variables-palette-2.css" >
   <link rel="stylesheet" href="tablestyle.css" >
</head>
<body>

<?php
$sSessId = 'ciktos8icvk11grtpkj3u610o3';
session_id($sSessId);
session_start();


require 'Customer.php'; 

echo("<table><caption>Customers</caption>");

echo("<tr><th>Last Name</th><th>First Name </th><th>Address</th><th>Phone</th><th>Customer Number</th><th>Mailing List</th><th>Comments</th></tr>");
foreach($_SESSION AS $value)
{
    $myCustomer=unserialize($value);

    

    	echo("<tr><td>".$myCustomer->getLastName()."</td>");
	echo("<td>".$myCustomer->getFirstName());
    echo("<td>".$myCustomer->getAddress());
	echo("<td>".$myCustomer->getPhone());
    echo("<td>".$myCustomer->getCustomerNumber());
    echo("<td>".$myCustomer->getMailingList());
	echo("<td>".$myCustomer->getComments()."</td></tr>");

}
echo("</table>");

?>
<form action="customerapp.php">
<form action="customerform.php" method="get">
</br>
<?php    session_destroy(); ?>
<input id="Submit1" type="submit" value="Reset Session" />
</form>
</body>
</html>